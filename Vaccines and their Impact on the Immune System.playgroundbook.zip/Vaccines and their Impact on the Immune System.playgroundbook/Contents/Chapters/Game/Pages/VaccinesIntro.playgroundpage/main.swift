//#-hidden-code

///import statements
import SpriteKit
import PlaygroundSupport
import UIKit


///Keep in mind this game works best wih results disabled.



///creates an SKView
//#-end-hidden-code

//:#localized(key: "introGame")


//#-hidden-code
//#-end-hidden-code
